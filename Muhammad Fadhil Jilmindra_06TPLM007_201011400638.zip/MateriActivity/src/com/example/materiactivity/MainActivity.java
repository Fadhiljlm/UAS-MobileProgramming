package com.example.materiactivity;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends Activity implements OnClickListener {
	private String[][] dataUser = {
	        {"ADMIN", "ADMIN", "Administrator"},
	        {"user1", "password1", "Nama User 1"},
	        {"user2", "password2", "Nama User 2"}
	    };
	    private EditText userNameET, passwordET;
	    private final int SUCCESS = 1;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        userNameET = (EditText) findViewById(R.id.userNameEditText);
        passwordET = (EditText) findViewById(R.id.passwordEditText);
        findViewById(R.id.loginButton).setOnClickListener(this);
        findViewById(R.id.tutupButton).setOnClickListener(this);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.loginButton:
                String userName = userNameET.getText().toString();
                String password = passwordET.getText().toString();

                boolean success = false;
                String namaUser = "";

                for (String[] userData : dataUser) {
                    if (userName.equals(userData[0]) && password.equals(userData[1])) {
                        success = true;
                        namaUser = userData[2];
                        break;
                    }
                }

                if (success) {
                    Intent intent = new Intent(MainActivity.this, SuccesActivity.class);
                    intent.putExtra("namaUser", namaUser);
                    startActivityForResult(intent, SUCCESS);
                } else {
                    Toast.makeText(MainActivity.this, "Username atau password salah", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.tutupButton:
            	System.exit(0);
                finish();
                break;
        }
    }
    
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SUCCESS && resultCode == RESULT_OK) {
        	 userNameET.setText("");
             passwordET.setText("");
        }
    }
}
